-- Convert the ped's object axes into pelvis-local axes at attachment time.
-- The exported harness is X-right, Y-forward, Z-up.
function VodenHarnessAttachmentOffset(ped)
    local fit = Config.HarnessFitOffset or vector3(0.0, 0.0, 0.0)
    local base = Config.HarnessAttachOffset
    -- Preserve the exact original attachment path when no fit is requested.
    if fit.x == 0.0 and fit.y == 0.0 and fit.z == 0.0 then return base end
    local pedOrigin = GetEntityCoords(ped)
    local target = GetOffsetFromEntityInWorldCoords(ped, fit.x, fit.y, fit.z)
    local delta = target - pedOrigin
    local boneOrigin = GetPedBoneCoords(ped, Config.HarnessBoneId, 0.0, 0.0, 0.0)
    local function component(x, y, z)
        local point = GetPedBoneCoords(ped, Config.HarnessBoneId, x, y, z)
        local axis = point - boneOrigin
        axis = axis / #axis
        return delta.x * axis.x + delta.y * axis.y + delta.z * axis.z
    end
    return base + vector3(component(1, 0, 0), component(0, 1, 0), component(0, 0, 1))
end

function VodenHarnessAttachmentRotation(ped)
    if not Config.HarnessAutoAlign then
        return Config.HarnessAttachRotation
    end

    local id = Config.HarnessBoneId
    local origin = GetPedBoneCoords(ped, id, 0.0, 0.0, 0.0)
    local base = GetOffsetFromEntityGivenWorldCoords(ped, origin.x, origin.y, origin.z)
    local function axis(x, y, z)
        local point = GetPedBoneCoords(ped, id, x, y, z)
        local localPoint = GetOffsetFromEntityGivenWorldCoords(ped, point.x, point.y, point.z)
        local v = localPoint - base
        return v / #v
    end
    local bx = axis(1.0, 0.0, 0.0)
    local by = axis(0.0, 1.0, 0.0)
    local bz = axis(0.0, 0.0, 1.0)

    -- Inverse of an orthonormal bone basis is its transpose.
    -- Extract Euler angles for rotationOrder 2 (ZXY).
    local x = math.asin(math.max(-1.0, math.min(1.0, bz.y)))
    local y, z
    if math.abs(math.cos(x)) > 0.00001 then
        y = math.atan(-bz.x, bz.z)
        z = math.atan(-bx.y, by.y)
    else
        y = 0.0
        z = math.atan(by.x, bx.x)
    end
    return vector3(math.deg(x), math.deg(y), math.deg(z))
end
