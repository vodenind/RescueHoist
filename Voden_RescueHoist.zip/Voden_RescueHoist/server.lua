local function supportedAircraft(vehicle)
    local entry=Config.Aircraft[GetEntityModel(vehicle)]
    if entry~=nil then return entry~=false end
    return Config.AutoDetectHelicopters and GetVehicleType(vehicle)=='heli'
end

local hoists = {}
local boarding = {}

RegisterNetEvent('voden_hoist:requestBoard', function(vehicleNetId)
    local src = source
    local state = hoists[vehicleNetId]
    if not state or not state.deployed then return end
    local attached = false
    for _, rider in pairs(state.attached) do
        if rider == src then attached = true end
    end
    if not attached then return end
    if state.length > Config.MinLength + Config.BoardTopTolerance then
        TriggerClientEvent('voden_hoist:boardResult', src, vehicleNetId, false, 'Retract the winch fully before boarding.')
        return
    end
    local ped = GetPlayerPed(src)
    local vehicle = NetworkGetEntityFromNetworkId(vehicleNetId)
    if ped == 0 or vehicle == 0 or not DoesEntityExist(vehicle) then return end
    if not supportedAircraft(vehicle) then return end
    if #(GetEntityCoords(ped) - GetEntityCoords(vehicle)) > VodenBoardDistance(vehicle) then return end
    boarding[src] = {vehicleNetId = vehicleNetId, state = state, expires = GetGameTimer() + 8000}
    TriggerClientEvent('voden_hoist:boardResult', src, vehicleNetId, true)
end)

local function sendState(target, state)
    TriggerClientEvent('voden_hoist:state', target, state)
end

RegisterNetEvent('voden_hoist:finishBoard', function(vehicleNetId)
    local src = source
    local request = boarding[src]
    local state = hoists[vehicleNetId]
    if not request or request.vehicleNetId ~= vehicleNetId then return end
    if request.state ~= state or GetGameTimer() > request.expires then boarding[src] = nil; return end
    local ped = GetPlayerPed(src)
    local vehicle = NetworkGetEntityFromNetworkId(vehicleNetId)
    -- Wait for the actual seated state to replicate before releasing the rider.
    if ped == 0 or vehicle == 0 or GetVehiclePedIsIn(ped, false) ~= vehicle then return end
    for slot, rider in pairs(state.attached) do
        if rider == src then state.attached[slot] = nil; if state.beltSizes then state.beltSizes[slot] = nil end end
    end
    if state.litterPatient == src then state.litterPatient = nil end
    boarding[src] = nil
    sendState(-1, state)
end)

RegisterNetEvent('voden_hoist:deployVirtual', function(vehicleNetId, length, hookPos)
    local src = source
    if hoists[vehicleNetId] then return end
    local vehicle=NetworkGetEntityFromNetworkId(vehicleNetId)
    local ped=GetPlayerPed(src)
    if vehicle==0 or ped==0 or not DoesEntityExist(vehicle) or not supportedAircraft(vehicle) then return end
    if GetVehiclePedIsIn(ped,false)~=vehicle then return end
    if Config.PilotOnly and GetPedInVehicleSeat(vehicle,-1)~=ped then return end
    length=Config.DefaultLength
    hoists[vehicleNetId] = {
        vehicleNetId = vehicleNetId,
        deployed = true,
        owner = src,
        length = length,
        hookPos = hookPos,
        hookVel = {x = 0.0, y = 0.0, z = 0.0},
        attached = {},
        beltSizes = {}
    }

    sendState(-1, hoists[vehicleNetId])
end)

RegisterNetEvent('voden_hoist:stow', function(vehicleNetId)
    local src = source
    local state = hoists[vehicleNetId]
    if not state then return end
    if state.owner ~= src then return end

    if state.litter then TriggerClientEvent('voden_hoist:litterMessage',src,'Use the litter recovery binding before stowing.'); return end
    hoists[vehicleNetId] = nil
    TriggerClientEvent('voden_hoist:remove', -1, vehicleNetId)
end)

RegisterNetEvent('voden_hoist:setLength', function(vehicleNetId, length)
    local src = source
    local state = hoists[vehicleNetId]
    if not state or state.owner ~= src then return end

    state.length = math.max(Config.MinLength, math.min(Config.MaxLength, tonumber(length) or state.length))
    sendState(-1, state)
end)

RegisterNetEvent('voden_hoist:setHookState', function(vehicleNetId, hookPos, hookVel, grounded)
    local src = source
    local state = hoists[vehicleNetId]
    if not state or state.owner ~= src then return end

    state.hookPos = hookPos
    state.hookVel = hookVel
    state.grounded = grounded == true

    -- Lightweight remote update only. Do not rebroadcast the entire hoist state
    -- 60+ times per second through reliable events.
    TriggerClientEvent('voden_hoist:hookUpdate', -1, vehicleNetId, hookPos, hookVel, state.grounded)
end)

RegisterNetEvent('voden_hoist:requestAttach', function(vehicleNetId, beltSize)
    local src = source
    local state = hoists[vehicleNetId]
    if not state then return end
    if state.litter and not state.litterGround then TriggerClientEvent('voden_hoist:litterMessage',src,'The litter is attached to the hook.'); return end

    for slot = 1, (Config.MaxDirectRiders or 1) do
        if state.attached[slot] == src then
            state.attached[slot] = nil; if state.beltSizes then state.beltSizes[slot] = nil end
            sendState(-1, state)
            return
        end
    end

    for slot = 1, (Config.MaxDirectRiders or 1) do
        if not state.attached[slot] then
            local size = type(beltSize) == 'string' and Config.BeltModels[beltSize] and beltSize or Config.BeltDefaultSize
            state.beltSizes = state.beltSizes or {}
            state.beltSizes[slot] = size
            state.attached[slot] = src
            sendState(-1, state)
            return
        end
    end

    TriggerClientEvent('voden_hoist:full', src)
end)

RegisterNetEvent('voden_hoist:requestAll', function()
    local src = source
    for _, state in pairs(hoists) do
        sendState(src, state)
    end
end)

AddEventHandler('playerDropped', function()
    local src = source
    boarding[src] = nil

    for vehicleNetId, state in pairs(hoists) do
        if state.owner == src then
            hoists[vehicleNetId] = nil
            TriggerClientEvent('voden_hoist:remove', -1, vehicleNetId)
        else
            local changed = false
            if state.litterPatient == src then state.litterPatient = nil; changed = true end
            for slot = 1, (Config.MaxDirectRiders or 1) do
                if state.attached[slot] == src then
                    state.attached[slot] = nil; if state.beltSizes then state.beltSizes[slot] = nil end
                    changed = true
                end
            end

            if changed then
                sendState(-1, state)
            end
        end
    end
end)

print('^2[Voden Rescue Hoist]^7 v3 full-virtual server loaded.')

-- One patient per litter. The server owns occupancy and validates proximity.
local function litterReply(src,text) TriggerClientEvent('voden_hoist:litterMessage',src,text) end
local function isOccupiedElsewhere(player)
    for _, h in pairs(hoists) do
        if h.litterPatient == player then return true end
        for _, rider in pairs(h.attached or {}) do if rider == player then return true end end
    end
    return false
end

local recoveries = {}
local function litterCenter(state)
    if state.litterGround then return vector3(state.litterGround.x,state.litterGround.y,state.litterGround.z) end
    return vector3(state.hookPos.x,state.hookPos.y,state.hookPos.z)-vector3(0,0,Config.LitterSuspensionDrop)
end
local function pilotAtTop(src,id)
    local h=hoists[id]; local ped=GetPlayerPed(src); local veh=NetworkGetEntityFromNetworkId(id)
    if not h or not h.deployed or ped==0 or veh==0 or not DoesEntityExist(veh) then return end
    if GetPedInVehicleSeat(veh,-1)~=ped or not supportedAircraft(veh) then return end
    if h.length>Config.MinLength+Config.BoardTopTolerance then litterReply(src,'Raise the empty hook or attached litter fully, then use the litter deployment/recovery binding.'); return end
    if not h.hookPos or #(vector3(h.hookPos.x,h.hookPos.y,h.hookPos.z)-GetEntityCoords(veh))>VodenBoardDistance(veh) then
        litterReply(src,'Wait until the hook reaches the helicopter, then use the litter deployment/recovery binding.'); return
    end
    return h,veh
end
RegisterNetEvent('voden_hoist:pilotLitter',function(id)
    local src=source; local h,veh=pilotAtTop(src,id)
    if not h then return end
    if recoveries[id] then return litterReply(src,'Patient boarding is already in progress.') end
    for _,_ in pairs(h.attached or {}) do return litterReply(src,'The rescuer must detach before deploying the litter.') end
    if not h.litter then
        h.litter=true; h.litterHeading=GetEntityHeading(veh)
        sendState(-1,h); return litterReply(src,'Litter attached. Lower it to the rescuer.')
    end
    if h.litterGround then return litterReply(src,'The rescuer must reconnect the litter to the hook first.') end
    if not h.litterPatient then
        h.litter=nil; sendState(-1,h); return litterReply(src,'Empty litter recovered and stowed.')
    end
    local request={patient=h.litterPatient,pilot=src,state=h,expires=GetGameTimer()+8000}
    recoveries[id]=request
    TriggerClientEvent('voden_hoist:recoverLitterPatient',h.litterPatient,id)
    SetTimeout(8000,function()
        if recoveries[id]==request then recoveries[id]=nil; litterReply(src,'Patient boarding timed out; litter remains on the hook.') end
    end)
end)
RegisterNetEvent('voden_hoist:finishLitterRecovery',function(id,success)
    local src=source;local req=recoveries[id];local h=hoists[id]
    if not req or req.patient~=src or req.state~=h or GetGameTimer()>req.expires then return end
    if not success then recoveries[id]=nil; return litterReply(req.pilot,'No free passenger seat or boarding failed. Litter remains attached.') end
    local ped=GetPlayerPed(src);local veh=NetworkGetEntityFromNetworkId(id)
    if ped==0 or veh==0 or GetVehiclePedIsIn(ped,false)~=veh or GetPedInVehicleSeat(veh,-1)==ped then return end
    recoveries[id]=nil;h.litterPatient=nil;h.litter=nil;h.litterGround=nil
    sendState(-1,h);litterReply(req.pilot,'Patient aboard. Litter recovered and stowed.')
end)
RegisterNetEvent('voden_hoist:litterAction',function(id,action,target)
    local src=source;local h=hoists[id]
    if not h or not h.litter or not h.hookPos then return end
    local ped=GetPlayerPed(src);local vehicle=NetworkGetEntityFromNetworkId(id)
    if ped==0 or vehicle==0 or not DoesEntityExist(vehicle) then return end
    if GetPlayerRoutingBucket(src)~=GetEntityRoutingBucket(vehicle) then return end
    -- Respawn cleanup is automatic and is not a patient interaction option.
    if action=='respawn' and h.litterPatient==src then h.litterPatient=nil;sendState(-1,h);return end
    if h.litterPatient==src then return litterReply(src,'The rescuer and pilot handle the litter.') end
    if GetVehiclePedIsIn(ped,false)~=0 then return end
    local center=litterCenter(h)
    if #(GetEntityCoords(ped)-center)>Config.LitterInteractDistance+0.5 then return end
    if recoveries[id] then return end
    if action=='detach' then
        if h.litterGround then return end
        if type(target)~='table' or type(target.x)~='number' or type(target.y)~='number' or type(target.z)~='number' then return end
        local ground=vector3(target.x,target.y,target.z)
        local distance=#(ground-center)
        if distance~=distance or distance>0.9 then return end
        h.litterGround={x=ground.x,y=ground.y,z=ground.z}
        litterReply(src,'Litter detached and resting on the ground.')
    elseif action=='reattach' then
        if not h.litterGround then return end
        for _,_ in pairs(h.attached or {}) do return litterReply(src,'The hook is occupied.') end
        local hook=vector3(h.hookPos.x,h.hookPos.y,h.hookPos.z)
        local desired=center+vector3(0,0,Config.LitterSuspensionDrop)
        if #(hook-desired)>1.0 then return litterReply(src,'Ask the pilot to lower the hook over the litter.') end
        h.litterGround=nil;litterReply(src,'Litter connected. Ready to raise.')
    elseif action=='load' then
        target=tonumber(target)
        if not h.litterGround then return litterReply(src,'Detach and set down the litter before loading.') end
        if h.litterPatient then return litterReply(src,'The litter is occupied.') end
        if not target or target==src or not GetPlayerName(target) or isOccupiedElsewhere(target) then return end
        local patient=GetPlayerPed(target)
        if patient==0 or GetVehiclePedIsIn(patient,false)~=0 then return end
        if GetPlayerRoutingBucket(target)~=GetPlayerRoutingBucket(src) then return end
        if #(GetEntityCoords(patient)-center)>Config.LitterInteractDistance+0.5 or #(GetEntityCoords(patient)-GetEntityCoords(ped))>Config.LitterInteractDistance then return end
        h.litterPatient=target;litterReply(src,('Loaded %s. Reconnect the litter when ready.'):format(GetPlayerName(target)))
    elseif action=='unload' then
        if not h.litterGround or not h.litterPatient then return end
        local patient=h.litterPatient;h.litterPatient=nil;sendState(-1,h)
        local a=math.rad(h.litterHeading or 0)
        TriggerClientEvent('voden_hoist:litterExitPosition',patient,{x=center.x+math.cos(a)*.95,y=center.y+math.sin(a)*.95,z=center.z+.15})
        return
    else return end
    sendState(-1,h)
end)
