fx_version 'cerulean'
game 'gta5'

author 'Voden Industries'
description 'Voden Rescue Hoist - virtual cable with real wearable SAR harness'
version '3.3.0-production'

lua54 'yes'

shared_script 'config.lua'
client_script 'harness_orientation.lua'
client_script 'hoist_visuals.lua'
client_script 'litter_client.lua'
client_script 'input.lua'
client_script 'aircraft.lua'
client_script 'client.lua'
server_script 'server.lua'

data_file 'DLC_ITYP_REQUEST' 'stream/voden_rescue_belts.ytyp'

data_file 'DLC_ITYP_REQUEST' 'stream/voden_rescue_hook.ytyp'

dependency 'ox_target'
data_file 'DLC_ITYP_REQUEST' 'stream/voden_rescue_litter.ytyp'
