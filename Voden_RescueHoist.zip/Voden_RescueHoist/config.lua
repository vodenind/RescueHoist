Config = {}

-- Explicit model entries override automatic rope-bone detection.
-- Set an entry to false to disable that model. Offsets are right/forward/up.
Config.AutoDetectHelicopters = true
Config.RopeBones = {'rope_attach_a', 'rope_attach_b'}
-- Models without a matching bone require an explicit fallbackOffset below.
Config.Aircraft = {
    [`as332`] = {
        label = 'Voden AS332 SAR',
        bone = 'rope_attach_a',
        fallbackOffset = vector3(1.35, 0.65, 0.20),
        doorIndex = 3,
    },
}

-- 100 ft = 30.48 metres / GTA world units for this use.
Config.MinLength = 1.50
Config.DefaultLength = 2.50
Config.MaxLength = 30.48
Config.ExtendSpeed = 2.2       -- m/s cable payout
Config.RetractSpeed = 2.6      -- m/s cable recovery

-- Solid steel cable visual; diameter in metres.
Config.SteelCableDiameter = 0.009

-- Manual rescue attachment - SINGLE PERSON HARNESS MODE
Config.PlayerAttachDistance = 2.0
Config.MaxDirectRiders = 1

-- Wearable rescue belt prop. Active models are streamed as voden_rescue_belt_s/m/l.
Config.HarnessModel = `voden_rescue_belt_m`
Config.BeltDefaultSize = 'm'
Config.BeltPedSizes = { [`mp_f_freemode_01`] = 's' }
Config.BeltModels = { s = `voden_rescue_belt_s`, m = `voden_rescue_belt_m`, l = `voden_rescue_belt_l` }
Config.BeltRingPoints = {
    [`voden_rescue_belt_s`] = vector3(0, 0.178, 0.238),
    [`voden_rescue_belt_m`] = vector3(0, 0.208, 0.238),
    [`voden_rescue_belt_l`] = vector3(0, 0.243, 0.238),
}
Config.HarnessBoneId = 11816 -- SKEL_Pelvis
Config.HarnessAttachOffset = vector3(0.00, 0.00, 0.00)
-- Fit adjustment in ped axes at attachment: right, forward, up (metres).
-- Restore the last visible placement; calibrate in-game before saving an offset.
Config.HarnessFitOffset = vector3(0.00, 0.00, 0.00)
-- Align the Z-up model to the ped when attaching, then follow the pelvis.
Config.HarnessAutoAlign = true
-- Manual bone-local rotation override, used only when auto alignment is false.
Config.HarnessAttachRotation = vector3(0.00, 0.00, 0.00)

-- Player root sits below the virtual hook. No heading or animation is forced.
Config.PlayerRootBelowHook = 0.88

-- Front D-ring location relative to pelvis bone. Used only for the short connector line.
-- Tweak these after the first in-game fit test if necessary.
Config.HarnessRingOffset = vector3(0, 0.208, 0.238)

-- Native controls below are suppressed while attached; action keys use Config.Keys.
Config.InteractControl = 38 -- native context control
Config.BoardControl = 23 -- F / INPUT_ENTER
Config.BoardTopTolerance = 0.35 -- metres above minimum cable length
Config.BoardMaxDistance = 4.0 -- rider to helicopter origin

Config.Keys = {
    Deploy = 'F6',
    Extend = 'PAGEDOWN',
    Retract = 'PAGEUP',
    Litter = 'F7',
    Interact = 'E',
    Board = 'F',
    SizeDown = 'LEFT',
    SizeUp = 'RIGHT',
}

Config.Commands = {
    Deploy = 'vhoist',
    Extend = '+vhoist_extend',
    Retract = '+vhoist_retract',
    Litter = 'voden_litter_pilot',
    Interact = 'vhoist_interact',
    Board = 'vhoist_board',
    SizeDown = 'vhoist_size_down',
    SizeUp = 'vhoist_size_up',
}

Config.OpenDoorOnDeploy = true
Config.CloseDoorOnStow = false
Config.PilotOnly = true
Config.Debug = false

-- No pose is forced while attached. The player remains free to use their own animations/emotes.

-- Basket + bridle top is 0.995 m above deck; hook throat is 0.257 m below its origin.
Config.LitterSuspensionDrop = 1.252
Config.LitterInteractDistance = 2.5
Config.LitterPatientOffset = vector3(0,0,0.15)
Config.LitterPatientHeading = 0.0

-- Winch ramp in metres/second squared. Grounded loads remain anchored until taut.
Config.WinchAcceleration = 3.5
Config.GroundedRiderRootHeight = 1.0


-- Shared client/server boarding radius for large custom aircraft.
function VodenBoardDistance(vehicle)
    local entry=Config.Aircraft[GetEntityModel(vehicle)]
    return type(entry)=='table' and entry.boardMaxDistance or Config.BoardMaxDistance
end
for _, action in ipairs({'Extend','Retract'}) do
    assert(Config.Commands[action]:sub(1,1)=='+','Hoist hold commands must start with +: '..action)
end
