print('^2[Voden Rescue Hoist]^7 v3.2.9 bounded-cable client parsed')


local states = {}
local controlledVehicleNet = nil
local extending = false
local retracting = false
local lastLengthSync = 0
local lastHookSync = 0
local harnessObjects = {}
local harnessLoadWarned = false
local boardRequest = nil
local blockExitUntil = 0
local beltPreviewActive = false
local beltSizes = {'s', 'm', 'l'}
local beltLabels = {s = 'Small', m = 'Medium', l = 'Large'}
local function selectedBeltSize(ped)
    local size = GetResourceKvpString('belt_size_' .. GetEntityModel(ped))
        or Config.BeltPedSizes[GetEntityModel(ped)] or Config.BeltDefaultSize
    return Config.BeltModels[size] and size or 'm'
end

local function notify(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(('~b~VODEN SAR~s~: %s'):format(msg))
    EndTextCommandThefeedPostTicker(false, false)
end

local function helpText(msg)
    msg=msg:gsub('~INPUT_ENTER~',function() return VodenKey('Board') end)
        :gsub('~INPUT_CONTEXT~',function() return VodenKey('Interact') end)
        :gsub('~INPUT_CELLPHONE_LEFT~',function() return VodenKey('SizeDown') end)
        :gsub('~INPUT_CELLPHONE_RIGHT~',function() return VodenKey('SizeUp') end)
    BeginTextCommandDisplayHelp('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

local function aircraftConfig(vehicle)
    if vehicle == 0 then return nil end
    return VodenAircraftConfig(vehicle)
end

local function winchPoint(vehicle, cfg)
    if cfg.bone then
        local bone = GetEntityBoneIndexByName(vehicle, cfg.bone)
        if bone and bone ~= -1 then
            return GetWorldPositionOfEntityBone(vehicle, bone), bone
        end
    end

    return GetOffsetFromEntityInWorldCoords(
        vehicle,
        cfg.fallbackOffset.x,
        cfg.fallbackOffset.y,
        cfg.fallbackOffset.z
    ), -1
end

local function getVehicle(netId)
    if not NetworkDoesEntityExistWithNetworkId(netId) then return 0 end
    return NetToVeh(netId)
end

local function vecLen(v)
    return math.sqrt(v.x*v.x + v.y*v.y + v.z*v.z)
end

local function norm(v)
    local l = vecLen(v)
    if l < 0.0001 then
        return vector3(0.0, 0.0, -1.0), 0.0
    end
    return vector3(v.x/l, v.y/l, v.z/l), l
end

local function slotForPlayer(state, serverId)
    if not state.attached then return nil end
    for slot = 1, (Config.MaxDirectRiders or 1) do
        if state.attached[slot] == serverId then return slot end
    end
    return nil
end

local function localPlayerServerId()
    return GetPlayerServerId(PlayerId())
end

local function beltModelForPed(ped, serverId)
    local size = Config.BeltPedSizes[GetEntityModel(ped)] or Config.BeltDefaultSize
    if serverId == localPlayerServerId() then size = selectedBeltSize(ped) end
    for _, state in pairs(states) do
        local slot = slotForPlayer(state, serverId)
        if slot and state.beltSizes then size = state.beltSizes[slot] or state.beltSizes[tostring(slot)] or size; break end
    end
    return Config.BeltModels[size] or Config.HarnessModel
end

local function requestHarnessModel(model)
    if not IsModelInCdimage(model) or not IsModelValid(model) then
        if not harnessLoadWarned then
            harnessLoadWarned = true
            notify('Harness model is not streamed: rescue belt assets are missing.')
            print('^1[Voden Rescue Hoist]^7 Missing streamed rescue belt model')
        end
        return false
    end

    if not HasModelLoaded(model) then
        RequestModel(model)
        local untilTime = GetGameTimer() + 2500
        while not HasModelLoaded(model) and GetGameTimer() < untilTime do Wait(0) end
    end
    return HasModelLoaded(model)
end

local function removeHarness(serverId)
    local obj = harnessObjects[serverId]
    if obj and DoesEntityExist(obj) then DeleteEntity(obj) end
    harnessObjects[serverId] = nil
end

local function ensureHarnessForPlayer(serverId)
    local player = GetPlayerFromServerId(serverId)
    if player == -1 then
        removeHarness(serverId)
        return nil
    end
    local ped = GetPlayerPed(player)
    if ped == 0 or not DoesEntityExist(ped) then return nil end
    if IsPedInAnyVehicle(ped, false) then removeHarness(serverId); return nil end

    local obj = harnessObjects[serverId]
    local model = beltModelForPed(ped, serverId)
    if obj and DoesEntityExist(obj) then
        if GetEntityModel(obj) == model and GetEntityAttachedTo(obj) == ped then return obj end
        removeHarness(serverId)
    end
    if not requestHarnessModel(model) then return nil end

    local p = GetEntityCoords(ped)
    obj = CreateObjectNoOffset(model, p.x, p.y, p.z, false, false, false)
    if obj == 0 then return nil end

    SetEntityCollision(obj, false, false)
    SetEntityInvincible(obj, true)
    local bone = GetPedBoneIndex(ped, Config.HarnessBoneId)
    local o = VodenHarnessAttachmentOffset(ped)
    local r = VodenHarnessAttachmentRotation(ped)
    AttachEntityToEntity(
        obj, ped, bone,
        o.x, o.y, o.z,
        r.x, r.y, r.z,
        false, false, false, true, 2, true
    )
    harnessObjects[serverId] = obj
    return obj
end

local function updateHarnessVisuals()
    local shouldHave = {}
    if beltPreviewActive then shouldHave[localPlayerServerId()] = true end
    for _, state in pairs(states) do
        if state.attached then
            for slot = 1, (Config.MaxDirectRiders or 1) do
                local sid = state.attached[slot]
                if sid then
                    shouldHave[sid] = true
                    ensureHarnessForPlayer(sid)
                end
            end
        end
    end
    for sid, _ in pairs(harnessObjects) do
        if not shouldHave[sid] then removeHarness(sid) end
    end
end

local function harnessRingWorld(ped)
    local o = Config.HarnessRingOffset
    for _, obj in pairs(harnessObjects) do
        if DoesEntityExist(obj) and GetEntityAttachedTo(obj) == ped then
            local ring = Config.BeltRingPoints[GetEntityModel(obj)] or o
            return GetOffsetFromEntityInWorldCoords(obj, ring.x, ring.y, ring.z)
        end
    end
    return GetPedBoneCoords(ped, Config.HarnessBoneId, o.x, o.y, o.z)
end

-- Client-local fit preview; save the printed values in config.lua for everyone.
RegisterCommand('vhoistfit', function(_, args)
    local x, y, z = tonumber(args[1]), tonumber(args[2]), tonumber(args[3])
    local function valid(v)
        return v and v == v and math.abs(v) <= 1.0
    end
    if not (valid(x) and valid(y) and valid(z)) then
        print('[Voden] Usage: /vhoistfit right forward up (metres, -1 to 1). Example: /vhoistfit 0 0 -0.18')
        return
    end
    Config.HarnessFitOffset = vector3(x, y, z)
    local ids = {}
    for sid in pairs(harnessObjects) do ids[#ids + 1] = sid end
    for _, sid in ipairs(ids) do
        removeHarness(sid)
        ensureHarnessForPlayer(sid)
    end
    print(('[Voden] Preview applied locally. Save: Config.HarnessFitOffset = vector3(%.3f, %.3f, %.3f)'):format(x, y, z))
end, false)

RegisterCommand('vhoistinspect', function()
    local count = 0
    for sid, obj in pairs(harnessObjects) do
        count = count + 1
        if DoesEntityExist(obj) then
            local ped = GetEntityAttachedTo(obj)
            local p = GetEntityCoords(obj)
            print(('[Voden] Harness player=%s object=%s attachedTo=%s world=(%.3f, %.3f, %.3f)'):format(sid, obj, ped, p.x, p.y, p.z))
            if ped ~= 0 and DoesEntityExist(ped) then
                local rel = GetOffsetFromEntityGivenWorldCoords(ped, p.x, p.y, p.z)
                print(('[Voden] Object origin relative to ped=(%.3f, %.3f, %.3f)'):format(rel.x, rel.y, rel.z))
            end
        else
            print(('[Voden] Harness player=%s has missing object=%s'):format(sid, obj))
        end
    end
    if count == 0 then print('[Voden] No harness objects tracked on this client. Attach to the hoist first.') end
    local fit = Config.HarnessFitOffset
    print(('[Voden] Current fit=(%.3f, %.3f, %.3f)'):format(fit.x, fit.y, fit.z))
end, false)

local function nearestHoistHook(maxDist)
    local ped = PlayerPedId()
    local p = GetEntityCoords(ped)
    local best, bestDist

    for _, state in pairs(states) do
        if state.deployed and state.hookPos then
            local hp = vector3(state.hookPos.x, state.hookPos.y, state.hookPos.z)
            local d = #(hp - p)
            if d <= maxDist and (not bestDist or d < bestDist) then
                best, bestDist = state, d
            end
        end
    end

    return best, bestDist
end

local function applyLocalAttachment(state, vehicle)
    local me = localPlayerServerId()
    local slot = slotForPlayer(state, me)
    if not slot or not state.hookPos or vehicle == 0 then return end

    local ped = PlayerPedId()
    -- Boarding confirmation can take a few network frames. Never pull a seated
    -- rider back out of the helicopter while the server updates the hoist.
    if GetVehiclePedIsIn(ped, false) == vehicle then return end
    if state.grounded then
        DisableControlAction(0, 30, true)
        DisableControlAction(0, 31, true)
        DisableControlAction(0, 22, true)
    end
    local hp = vector3(state.hookPos.x, state.hookPos.y, state.hookPos.z)

    -- Suspend the player's root below the hook, but deliberately do NOT touch
    -- heading, arm position, or animation. Any compatible player emote remains theirs.
    local target = vector3(hp.x, hp.y, hp.z - Config.PlayerRootBelowHook)
    SetEntityCoordsNoOffset(ped, target.x, target.y, target.z, true, true, false)
    SetEntityVelocity(ped, 0.0, 0.0, 0.0)

    -- Ensure the real harness prop is attached to the pelvis.
    ensureHarnessForPlayer(me)


end

local function deployOrStow()
    local ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    local cfg = aircraftConfig(vehicle)

    if controlledVehicleNet then
        TriggerServerEvent('voden_hoist:stow', controlledVehicleNet)
        return
    end

    if not cfg then
        return notify('You are not in a supported SAR helicopter.')
    end

    if Config.PilotOnly and GetPedInVehicleSeat(vehicle, -1) ~= ped then
        return notify('Only the pilot can deploy the hoist.')
    end

    local top, bone = winchPoint(vehicle, cfg)
    if bone == -1 then
        notify('Configured rope bone not found; using the configured winch offset.')
    end

    local vehNet = NetworkGetNetworkIdFromEntity(vehicle)
    controlledVehicleNet = vehNet

    if Config.OpenDoorOnDeploy and cfg.doorIndex then
        SetVehicleDoorOpen(vehicle, cfg.doorIndex, false, false)
    end

    local initialHook = {
        x = top.x,
        y = top.y,
        z = top.z - Config.DefaultLength
    }

    TriggerServerEvent(
        'voden_hoist:deployVirtual',
        vehNet,
        Config.DefaultLength,
        initialHook
    )

    notify('Rescue hoist deployed.')
end

RegisterCommand(Config.Commands.Deploy, deployOrStow, false)
RegisterKeyMapping(Config.Commands.Deploy, 'Deploy / stow Voden rescue hoist', 'keyboard', Config.Keys.Deploy)

RegisterCommand(Config.Commands.Extend, function()
    extending = true
end, false)

RegisterCommand(Config.Commands.Extend:gsub('^%+', '-'), function()
    extending = false
end, false)

RegisterKeyMapping(Config.Commands.Extend, 'Extend rescue hoist cable', 'keyboard', Config.Keys.Extend)

RegisterCommand(Config.Commands.Retract, function()
    retracting = true
end, false)

RegisterCommand(Config.Commands.Retract:gsub('^%+', '-'), function()
    retracting = false
end, false)

RegisterKeyMapping(Config.Commands.Retract, 'Retract rescue hoist cable', 'keyboard', Config.Keys.Retract)

RegisterNetEvent('voden_hoist:state', function(state)
    local previous = states[state.vehicleNetId]
    if previous then
        state._target = state.hookPos
        state.hookPos = previous.hookPos
        state._ground = previous._ground
        state._groundChecked = previous._groundChecked
        state._groundPoint = previous._groundPoint
        state._loadKind = previous._loadKind
        if controlledVehicleNet == state.vehicleNetId then
            state.length = previous.length
            state.hookVel = previous.hookVel
            state.grounded = previous.grounded
            state._speed = previous._speed
            state._lengthDirty = previous._lengthDirty
        end
    end
    states[state.vehicleNetId] = state
    VodenSetLitterState(state)
end)

RegisterNetEvent('voden_hoist:hookUpdate', function(vehicleNetId, hookPos, hookVel, grounded)
    local state = states[vehicleNetId]
    if not state then return end

    -- The owner already simulates its hook locally every frame.
    -- Remote clients only consume these throttled snapshots.
    if controlledVehicleNet ~= vehicleNetId then
        state._target = hookPos
        state.hookVel = hookVel
        state.grounded = grounded
    end
end)

RegisterNetEvent('voden_hoist:remove', function(vehicleNetId)
    if controlledVehicleNet==vehicleNetId and Config.CloseDoorOnStow then
        local vehicle=getVehicle(vehicleNetId)
        local cfg=aircraftConfig(vehicle)
        if cfg and cfg.doorIndex then SetVehicleDoorShut(vehicle,cfg.doorIndex,false) end
    end
    states[vehicleNetId] = nil
    VodenRemoveHoistVisual(vehicleNetId)
    VodenRemoveLitter(vehicleNetId,true)
    updateHarnessVisuals()
    if controlledVehicleNet == vehicleNetId then
        controlledVehicleNet = nil
    end
end)

RegisterNetEvent('voden_hoist:full', function()
    notify('The rescue hook is occupied.')
end)

RegisterNetEvent('voden_hoist:boardResult', function(netId, approved, message)
    if not boardRequest or boardRequest.netId ~= netId then return end
    if GetGameTimer() >= boardRequest.expires or boardRequest.seating then return end
    if not approved then boardRequest = nil; notify(message or 'Unable to board.'); return end
    local state = states[netId]
    local vehicle = getVehicle(netId)
    local ped = PlayerPedId()
    if not state or not (slotForPlayer(state, localPlayerServerId()) or state.litterPatient == localPlayerServerId()) or vehicle == 0 then
        boardRequest = nil
        return
    end
    if (state.length or Config.DefaultLength) > Config.MinLength + Config.BoardTopTolerance
        or #(GetEntityCoords(ped) - GetEntityCoords(vehicle)) > VodenBoardDistance(vehicle) then
        boardRequest = nil
        notify('The winch moved away from the boarding position. Retract and try again.')
        return
    end
    local seat = nil
    -- Cabin seats first, copilot as fallback. Never use the pilot seat (-1).
    local passengers = GetVehicleMaxNumberOfPassengers(vehicle)
    for i = 1, passengers - 1 do
        if IsVehicleSeatFree(vehicle, i, true) then seat = i; break end
    end
    if seat == nil and passengers > 0 and IsVehicleSeatFree(vehicle, 0, true) then seat = 0 end
    if seat == nil then boardRequest = nil; notify('No passenger seats available. You remain on the winch.'); return end
    ClearPedTasksImmediately(ped)
    SetPedIntoVehicle(ped, vehicle, seat)
    blockExitUntil = GetGameTimer() + 1200
    boardRequest.seating = true
    CreateThread(function()
        local request = boardRequest
        Wait(0)
        if GetVehiclePedIsIn(ped, false) ~= vehicle then
            boardRequest = nil
            notify('Boarding failed. You remain on the winch.')
            return
        end
        removeHarness(localPlayerServerId())
        notify('Boarded the helicopter.')
        while boardRequest == request and GetGameTimer() < request.expires do
            if GetVehiclePedIsIn(ped, false) ~= vehicle then break end
            local current = states[netId]
            if not current or not (slotForPlayer(current, localPlayerServerId()) or current.litterPatient == localPlayerServerId()) then break end
            TriggerServerEvent('voden_hoist:finishBoard', netId)
            Wait(250)
        end
        if boardRequest == request then boardRequest = nil end
    end)
end)

RegisterCommand('vhoistresetpose', function()
    notify('The cable-holding pose runs while attached. Detach to release it.')
end, false)

CreateThread(function()
    local last = GetGameTimer()

    while true do
        Wait(0)
        local now = GetGameTimer()
        local dt = math.min(0.05, (now - last) / 1000.0)
        last = now

        if controlledVehicleNet then
            local state = states[controlledVehicleNet]
            if state then
                local targetSpeed = 0.0
                if extending and not retracting then targetSpeed = Config.ExtendSpeed end
                if retracting and not extending then targetSpeed = -Config.RetractSpeed end
                local speed = state._speed or 0.0
                local step = Config.WinchAcceleration * dt
                speed = speed + math.max(-step, math.min(step, targetSpeed-speed))
                local oldLength = state.length
                state.length = math.max(Config.MinLength, math.min(Config.MaxLength, oldLength+speed*dt))
                if state.length == oldLength then speed = 0.0 end
                state._speed = speed
                state._lengthDirty = state._lengthDirty or state.length ~= oldLength
                if state._lengthDirty and (now-lastLengthSync > 150 or speed == 0.0) then
                    TriggerServerEvent('voden_hoist:setLength', state.vehicleNetId, state.length)
                    lastLengthSync = now
                    state._lengthDirty = false
                end
            end
        end
    end
end)

-- Full virtual hook physics.
CreateThread(function()
    local last = GetGameTimer()

    while true do
        Wait(0)
        local now = GetGameTimer()
        local dt = math.min(0.05, (now - last) / 1000.0)
        last = now

        updateHarnessVisuals()

        for _, state in pairs(states) do
            local vehicle = getVehicle(state.vehicleNetId)

            if vehicle ~= 0 then
                local cfg = aircraftConfig(vehicle)
                if cfg then
                    local top = winchPoint(vehicle, cfg)
                    local desiredLen = state.length or Config.DefaultLength

                    if not state.hookPos then
                        state.hookPos = {
                            x = top.x,
                            y = top.y,
                            z = top.z - desiredLen
                        }
                    end

                    if not state.hookVel then
                        state.hookVel = {x = 0.0, y = 0.0, z = 0.0}
                    end

                    local hp = vector3(
                        state.hookPos.x,
                        state.hookPos.y,
                        state.hookPos.z
                    )

                    local hv = vector3(
                        state.hookVel.x,
                        state.hookVel.y,
                        state.hookVel.z
                    )

                    if controlledVehicleNet == state.vehicleNetId then
                        -- Query the load footprint, not the aircraft's ground altitude.
                        if not state._groundChecked or now-state._groundChecked > 100 then
                            state._groundChecked = now
                            state._ground = nil
                            state._groundPoint = hp
                            local reach = state.litter and not state.litterGround and 1.05 or 0.25
                            for _, offset in ipairs({{0,0},{reach,0},{-reach,0},{0,reach},{0,-reach}}) do
                                local found, z = GetGroundZFor_3dCoord(hp.x+offset[1],hp.y+offset[2],hp.z+0.5,false)
                                if found then state._ground = math.max(state._ground or z,z) end
                            end
                        end
                        local clearance = 0.32
                        local loadKind = 'hook'
                        if state.litter and not state.litterGround then
                            clearance = Config.LitterSuspensionDrop + 0.07
                            loadKind = 'litter'
                        elseif next(state.attached or {}) then
                            -- Conservative pelvis clearance also covers the seated pose's feet.
                            clearance = Config.PlayerRootBelowHook + Config.GroundedRiderRootHeight
                            loadKind = 'rider'
                        end
                        if state._loadKind ~= loadKind then state.grounded = false end
                        state._loadKind = loadKind
                        local floor = state._ground and state._ground+clearance
                        local distance = #(hp-top)
                        if state.grounded and floor and distance <= desiredLen+0.025 then
                            hp = vector3(hp.x,hp.y,math.max(hp.z,floor))
                            hv = vector3(0,0,0)
                        else
                            state.grounded = false
                            hv = (hv+vector3(0,0,-9.81)*dt)*math.exp(-0.9*dt)
                            hp = hp+hv*dt
                            local dir, dist = norm(hp-top)
                            if dist > desiredLen then
                                hp = top+dir*desiredLen
                                local radial = hv.x*dir.x+hv.y*dir.y+hv.z*dir.z
                                if radial > 0 then hv = hv-dir*radial end
                            end
                            if floor and hp.z <= floor then
                                hp = vector3(hp.x,hp.y,floor)
                                hv = vector3(0,0,0)
                                state.grounded = true
                            end
                        end
                    elseif state._target then
                        local target = vector3(state._target.x,state._target.y,state._target.z)
                        -- Do not run a second gravity simulation on receiving clients.
                        hp = state.grounded and target or hp+(target-hp)*(1-math.exp(-18*dt))
                    end

                    state.hookPos = {x = hp.x, y = hp.y, z = hp.z}
                    state.hookVel = {x = hv.x, y = hv.y, z = hv.z}

                    -- Operator sends hook state at a limited rate.
                    -- NEVER send this every frame: reliable events can overflow
                    -- FiveM's network queue and disconnect the client.
                    if controlledVehicleNet == state.vehicleNetId and now - lastHookSync >= 100 then
                        TriggerServerEvent(
                            'voden_hoist:setHookState',
                            state.vehicleNetId,
                            state.hookPos,
                            state.hookVel,
                            state.grounded == true
                        )
                        lastHookSync = now
                    end

                    VodenUpdateLitter(state, vehicle, hp)
                    applyLocalAttachment(state, vehicle)
                    local hookTop = hp
                    local heading = GetEntityHeading(vehicle)
                    for _, sid in pairs(state.attached or {}) do
                        local player = GetPlayerFromServerId(sid)
                        if player ~= -1 then
                            local ped = GetPlayerPed(player)
                            local obj = harnessObjects[sid]
                            if obj and DoesEntityExist(obj) and not IsPedInAnyVehicle(ped, false) then
                                -- The forged hook's lower throat rests on the belt ring.
                                hookTop = harnessRingWorld(ped) + vector3(0,0,0.257)
                                heading = GetEntityHeading(ped)
                                break
                            end
                        end
                    end
                    VodenDrawSteelCable(top, hookTop, desiredLen, state.grounded == true, state.vehicleNetId)
                    VodenDrawRescueHook(state.vehicleNetId, hookTop, heading)
                end
            end
        end
    end
end)

CreateThread(function()
    while true do
        local sleep = 500
        local me = localPlayerServerId()
        local state = nil
        for _, candidate in pairs(states) do
            if slotForPlayer(candidate, me) or candidate.litterPatient == me then state = candidate; break end
        end
        state = state or nearestHoistHook(Config.PlayerAttachDistance)

        if boardRequest and GetGameTimer() >= boardRequest.expires then
            boardRequest = nil
            notify('Boarding request timed out. Try again.')
        end
        if GetGameTimer() < blockExitUntil then
            sleep = 0
            DisableControlAction(0, 75, true)
            DisableControlAction(0, Config.BoardControl, true)
        end

        if state then
            sleep = 0
            local me = localPlayerServerId()
            local slot = slotForPlayer(state, me) or (state.litterPatient == me and -1)

            if state.litterPatient == me then
                beltPreviewActive = false
                helpText('In rescue litter | Rescuer handles loading; pilot handles recovery')
            elseif slot then
                beltPreviewActive = false
                DisableControlAction(0, Config.BoardControl, true)
                local vehicle = getVehicle(state.vehicleNetId)
                local ped = PlayerPedId()
                local atTop = vehicle ~= 0
                    and (state.length or Config.DefaultLength) <= Config.MinLength + Config.BoardTopTolerance
                    and #(GetEntityCoords(ped) - GetEntityCoords(vehicle)) <= VodenBoardDistance(vehicle)
                if boardRequest then
                    helpText('Boarding helicopter...')
                elseif atTop then
                    helpText('Press ~INPUT_ENTER~ to board helicopter | ~INPUT_CONTEXT~ to detach')
                    if VodenPressed('Board') then
                        boardRequest = {netId = state.vehicleNetId, expires = GetGameTimer() + 7000}
                        TriggerServerEvent('voden_hoist:requestBoard', state.vehicleNetId)
                    end
                else
                    helpText('Press ~INPUT_CONTEXT~ to detach | Retract the winch fully to board')
                end
            elseif state.litter and not state.litterGround then
                beltPreviewActive = false
                helpText('Rescuer: use third eye to set down or reconnect the litter')
            else
                local ped = PlayerPedId()
                local available = false
                for i = 1, (Config.MaxDirectRiders or 1) do
                    if not state.attached or not state.attached[i] then available = true end
                end
                beltPreviewActive = available and not IsPedInAnyVehicle(ped, false) and not IsEntityDead(ped)
                if beltPreviewActive then
                    DisableControlAction(0, 174, true)
                    DisableControlAction(0, 175, true)
                    local size = selectedBeltSize(ped)
                    local step = VodenPressed('SizeDown') and -1
                        or (VodenPressed('SizeUp') and 1 or 0)
                    if step ~= 0 then
                        local index = size == 's' and 1 or (size == 'm' and 2 or 3)
                        size = beltSizes[((index - 1 + step) % 3) + 1]
                        SetResourceKvp('belt_size_' .. GetEntityModel(ped), size)
                    end
                    ensureHarnessForPlayer(me)
                    helpText(('Belt: %s | ~INPUT_CELLPHONE_LEFT~ / ~INPUT_CELLPHONE_RIGHT~ size | ~INPUT_CONTEXT~ attach'):format(beltLabels[size]))
                else
                    helpText('Rescue hook unavailable')
                end
            end

            if state.litterPatient ~= me and not boardRequest and (slot or beltPreviewActive) and VodenPressed('Interact') then
                if state.litterPatient == me then
                    TriggerServerEvent('voden_hoist:litterAction',state.vehicleNetId,'unload')
                else
                    TriggerServerEvent('voden_hoist:requestAttach',state.vehicleNetId,selectedBeltSize(PlayerPedId()))
                end
                Wait(300)
            end
        else
            beltPreviewActive = false
        end

        Wait(sleep)
    end
end)

AddEventHandler('onClientResourceStart', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    CreateThread(function()
        Wait(1200)
        notify('Real-harness hoist logic loaded.')
        print('^2[Voden Rescue Hoist]^7 v3.3 production-clean harness hoist loaded.')
        TriggerServerEvent('voden_hoist:requestAll')
    end)
end)


AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    for sid, _ in pairs(harnessObjects) do removeHarness(sid) end
end)
