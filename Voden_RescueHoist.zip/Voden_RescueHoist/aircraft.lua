function VodenAircraftConfig(vehicle)
    if vehicle==0 or not DoesEntityExist(vehicle) then return nil end
    local explicit=Config.Aircraft[GetEntityModel(vehicle)]
    if explicit==false then return nil end
    if explicit then
        if explicit.bone and GetEntityBoneIndexByName(vehicle,explicit.bone)~=-1 then return explicit end
        if explicit.fallbackOffset then return explicit end
        return nil
    end
    if not Config.AutoDetectHelicopters or not IsThisModelAHeli(GetEntityModel(vehicle)) then return nil end
    for _, name in ipairs(Config.RopeBones) do
        if GetEntityBoneIndexByName(vehicle,name)~=-1 then return {bone=name} end
    end
end
