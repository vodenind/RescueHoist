-- Key events expire so a press made outside interaction range cannot fire later.
local pressed = {}
for _, action in ipairs({'Interact','Board','SizeDown','SizeUp'}) do
    local name = action
    RegisterCommand(Config.Commands[name],function()
        if not IsPauseMenuActive() and not IsNuiFocused() then pressed[name]=GetGameTimer() end
    end,false)
    RegisterKeyMapping(Config.Commands[name],'Rescue hoist: '..name,'keyboard',Config.Keys[name])
end
function VodenPressed(name)
    local time=pressed[name]; pressed[name]=nil
    return time ~= nil and GetGameTimer()-time < 150
end
function VodenKey(name)
    local key=GetControlInstructionalButton(0,GetHashKey(Config.Commands[name]) | 0x80000000,true)
    if key and key:sub(1,2)=='t_' then return key:sub(3) end
    return name -- Icon-only/controller bindings use the action name.
end
