VODEN RESCUE HOIST - PRODUCTION BUILD 3.3.0

FiveM-ready rescue hoist resource using the Voden virtual steel cable, rescue hook,
wearable rescue belt, and litter workflow.

REQUIREMENTS
- OneSync
- ox_target

INSTALL
1. Put Voden_RescueHoist in your server resources folder.
2. Ensure ox_target starts before this resource.
3. Add/keep: ensure Voden_RescueHoist
4. Restart the resource/server and reconnect for streamed asset changes.

CONTROLS
F6       Deploy / stow winch
PageDown Extend cable
PageUp   Retract cable
E        Attach / detach direct rescue belt rider
F        Board aircraft when raised to boarding position
F7       Pilot litter deploy / recover
Left/Right Select rescue belt size

DIRECT HOIST
- One direct rider maximum.
- A real streamed Voden rescue belt prop is attached at the pelvis.
- The hook/cable connects to the belt ring.
- No player pose or animation is forced. Players may use their own compatible
  emotes/animations while suspended.

LITTER
The existing pilot/rescuer litter workflow is preserved. ox_target is used for
litter ground interactions. The litter can be lowered, detached, loaded with a
patient, reconnected, raised, and recovered into the aircraft.

PRODUCTION CLEANUP
- Removed Blender/OBJ/DDS/PNG source-model working files from the runtime package.
- Removed obsolete freemode clothing-harness collection assets and unused clothing script.
- Removed stale validation reports, preview images, and build notes.
- Retained only runtime scripts and streamed assets used by the active belt, hook,
  cable, and litter systems.
- Removed forced rappel/rope pose logic.

NOTES
The editable source models are intentionally not included in this production ZIP.
Keep a separate development archive if future mesh editing is required.
