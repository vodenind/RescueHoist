# Controls

Edit `Config.Keys` in config.lua for Deploy, Extend, Retract, Litter, Interact,
Board, SizeDown and SizeUp. These are FiveM keyboard names, e.g. F6, E, PAGEUP.
Restart the resource after editing. Each action appears in FiveM Key Bindings.

FiveM saves each player's chosen bindings: changing server defaults does not
overwrite existing player assignments. Existing players can change/reset the
Voden entries in Settings > Key Bindings > FiveM. Do not rename commands to force
new defaults. Config.Commands is available for deliberate command customization;
Extend and Retract must retain a leading +; release commands are derived from them.
Avoid assigning two actions or another resource to the same key.

BoardControl and InteractControl are legacy native-control settings, not action
bindings. Grounded movement/jump suppression and vehicle-exit suppression use GTA
control IDs intentionally. The third-eye activation key belongs to ox_target:
configure it there, not in this resource. Other resources can still cause conflicts.

# Helicopters

Automatic detection is enabled by Config.AutoDetectHelicopters. Helicopter models
with any bone in Config.RopeBones work without a model entry. Detection currently
tries rope_attach_a followed by rope_attach_b. Add other exact bone names as needed.
Automatic detection does not open a door because door layouts vary by aircraft.

Explicit Config.Aircraft entries take precedence. Example (replace the placeholder
with your actual Black Hawk spawn name and the bone/offset from that model):

```lua
Config.Aircraft[`your_blackhawk_spawn_name`] = {
    bone = 'rope_attach_a',
    fallbackOffset = vector3(1.35, 0.65, 0.20), -- example only: calibrate to model
    doorIndex = 3, -- optional; use that model's actual rescue door index
    boardMaxDistance = 6.0, -- optional for larger fuselages
}
```

If the bone exists, it is used. Otherwise the explicit fallbackOffset is used.
Omit fallbackOffset to require the named bone. An offset-only entry is supported.
Offsets are metres in vehicle axes: right, forward, up. No universal offset fits
every model. Set a model entry to false to block it; disable automatic detection
to use only explicit entries. Passenger boarding requires a free passenger seat.

The AS332 entry is retained. Test each custom aircraft's winch location, door and
seats before deployment; this build has not been run against every helicopter.

Validation checklist: rebind each action; hold/release both winch directions;
attach/detach, resize and board; deploy/recover litter. Repeat the sequence on an
auto-detected helicopter, an offset-only model and a deliberately disabled model.
The belt, hook, ground-pool rendering and litter assets are unchanged.
