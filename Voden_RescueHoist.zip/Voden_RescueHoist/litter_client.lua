local states, visuals, zones = {}, {}, {}
local patientPed, patientSeen = nil, 0
local suppressPatient = false
local model = `voden_rescue_litter`
local dict, clip = 'anim@gangops@morgue@table@', 'body_search'
local function message(text)
    BeginTextCommandThefeedPost('STRING'); AddTextComponentSubstringPlayerName(text); EndTextCommandThefeedPostTicker(false,false)
end
RegisterNetEvent('voden_hoist:litterMessage', message)

function VodenSetLitterState(state)
    states[state.vehicleNetId] = state
    if state.litterPatient ~= GetPlayerServerId(PlayerId()) then suppressPatient = false end
end

local function stopPatient()
    if patientPed and DoesEntityExist(patientPed) then StopAnimTask(patientPed,dict,clip,4.0) end
    patientPed = nil
end

function VodenRemoveLitter(id, forget)
    if visuals[id] and DoesEntityExist(visuals[id]) then DeleteEntity(visuals[id]) end
    visuals[id] = nil
    if zones[id] then
        if GetResourceState('ox_target') == 'started' then exports.ox_target:removeZone(zones[id].id) end
        zones[id] = nil
    end
    if forget then states[id] = nil end
end

function VodenUpdateLitter(state, vehicle, hp)
    states[state.vehicleNetId] = state
    if not state.litter then
        if visuals[state.vehicleNetId] then VodenRemoveLitter(state.vehicleNetId,false) end
        return
    end
    local pos = state.litterGround and vector3(state.litterGround.x,state.litterGround.y,state.litterGround.z) or hp - vector3(0,0,Config.LitterSuspensionDrop)
    local obj = visuals[state.vehicleNetId]
    if not obj or not DoesEntityExist(obj) then
        RequestModel(model)
        if not HasModelLoaded(model) then return end
        obj = CreateObjectNoOffset(model,pos.x,pos.y,pos.z,false,false,false)
        if obj == 0 then return end
        SetEntityCollision(obj,false,false); FreezeEntityPosition(obj,true); SetEntityInvincible(obj,true)
        visuals[state.vehicleNetId] = obj
    end
    SetEntityCoordsNoOffset(obj,pos.x,pos.y,pos.z,false,false,false)
    SetEntityHeading(obj,state.litterHeading or GetEntityHeading(vehicle))
    if state.litterPatient == GetPlayerServerId(PlayerId()) then
        if suppressPatient then return end
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped,false) then stopPatient(); return end
        if patientPed and patientPed ~= ped then stopPatient() end
        patientPed = ped; patientSeen = GetGameTimer()
        local o = Config.LitterPatientOffset
        local p = GetOffsetFromEntityInWorldCoords(obj,o.x,o.y,o.z)
        SetEntityCoordsNoOffset(ped,p.x,p.y,p.z,true,true,false)
        SetEntityHeading(ped,(state.litterHeading or 0)+Config.LitterPatientHeading)
        SetEntityVelocity(ped,0,0,0)
        if not IsEntityDead(ped) then
            RequestAnimDict(dict)
            if HasAnimDictLoaded(dict) and not IsEntityPlayingAnim(ped,dict,clip,3) then
                TaskPlayAnim(ped,dict,clip,4.0,-4.0,-1,1,0,false,false,false)
            end
        end
    end
end

RegisterNetEvent('voden_hoist:litterExitPosition',function(position)
    stopPatient()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped,false) then SetEntityCoordsNoOffset(ped,position.x,position.y,position.z,true,true,false) end
end)

AddEventHandler('playerSpawned',function()
    for id,state in pairs(states) do
        if state.litterPatient == GetPlayerServerId(PlayerId()) then
            suppressPatient = true
            stopPatient()
            TriggerServerEvent('voden_hoist:litterAction',id,'respawn')
        end
    end
end)

local function hasRider(s) for _,_ in pairs(s.attached or {}) do return true end return false end
local function nearestOther(pos)
    local best, distance
    for _, player in ipairs(GetActivePlayers()) do
        if player ~= PlayerId() then
            local ped = GetPlayerPed(player)
            local d = #(GetEntityCoords(ped)-pos)
            if d <= Config.LitterInteractDistance and (not distance or d<distance) then best=GetPlayerServerId(player); distance=d end
        end
    end
    return best
end
local function request(id, action, target) TriggerServerEvent('voden_hoist:litterAction',id,action,target) end

-- Global ox_target options use our player-to-hook distance, not the camera
-- ray endpoint. The visual hook has no collision surface to aim at.

local registered=false
local optionNames={'voden_litter_detach','voden_litter_reattach','voden_litter_load','voden_litter_unload'}
local function nearestAction(action)
    local me=GetEntityCoords(PlayerPedId());local sid=GetPlayerServerId(PlayerId());local best,dist
    if IsPedInAnyVehicle(PlayerPedId(),false) then return end
    for id,s in pairs(states) do
        if s.litter and s.hookPos and s.litterPatient~=sid then
            local eligible=(action=='detach' and not s.litterGround)
                or (action=='reattach' and s.litterGround and not hasRider(s))
                or (action=='load' and s.litterGround and not s.litterPatient)
                or (action=='unload' and s.litterGround and s.litterPatient)
            local p=s.litterGround and vector3(s.litterGround.x,s.litterGround.y,s.litterGround.z)
                or vector3(s.hookPos.x,s.hookPos.y,s.hookPos.z)-vector3(0,0,Config.LitterSuspensionDrop)
            local d=#(me-p)
            if eligible and d<=Config.LitterInteractDistance and (not dist or d<dist) then best=id;dist=d end
        end
    end
    return best
end
local function perform(action)
    local id=nearestAction(action)
    if not id then return message('No litter available for that action nearby.') end
    if action=='detach' then
        local s=states[id];local p=vector3(s.hookPos.x,s.hookPos.y,s.hookPos.z)-vector3(0,0,Config.LitterSuspensionDrop)
        local found,z=GetGroundZFor_3dCoord(p.x,p.y,p.z+.5,false)
        if not found or math.abs(p.z-(z+.07))>.85 then return message('Ask the pilot to lower the litter close to the ground first.') end
        request(id,'detach',{x=p.x,y=p.y,z=z+.07})
    elseif action=='load' then
        local target=nearestOther(GetEntityCoords(PlayerPedId()))
        if target then request(id,'load',target) else message('Stand beside the injured player and litter.') end
    else request(id,action) end
end
local function registerOptions()
    local options={}
    for _,item in ipairs({
        {'detach','Detach litter and set on ground','fa-solid fa-link-slash'},
        {'reattach','Connect litter to lowered hook','fa-solid fa-link'},
        {'load','Place nearest patient in litter','fa-solid fa-user-plus'},
        {'unload','Unload patient from grounded litter','fa-solid fa-user-minus'}
    }) do
        local action=item[1]
        options[#options+1]={name='voden_litter_'..action,label=item[2],icon=item[3],
            canInteract=function() return nearestAction(action)~=nil end,onSelect=function() perform(action) end}
    end
    exports.ox_target:addGlobalOption(options);registered=true
end
RegisterCommand('vlitter',function(_,args)
    local action=args[1]
    if action~='detach' and action~='reattach' and action~='load' and action~='unload' then return message('/vlitter detach | load | reattach | unload. Pilot: use the Deploy / recover rescue litter binding.') end
    perform(action)
end,false)
RegisterCommand(Config.Commands.Litter,function()
    local ped=PlayerPedId();local veh=GetVehiclePedIsIn(ped,false)
    if veh==0 or GetPedInVehicleSeat(veh,-1)~=ped then return message('Only the helicopter pilot can deploy or recover the litter.') end
    TriggerServerEvent('voden_hoist:pilotLitter',NetworkGetNetworkIdFromEntity(veh))
end,false)
RegisterKeyMapping(Config.Commands.Litter,'Deploy / recover rescue litter (pilot)','keyboard',Config.Keys.Litter)
RegisterNetEvent('voden_hoist:recoverLitterPatient',function(id)
    local s=states[id];local me=GetPlayerServerId(PlayerId())
    if not s or s.litterPatient~=me or s.litterGround then return end
    local vehicle=NetToVeh(id);local ped=PlayerPedId();local seat
    if vehicle==0 then TriggerServerEvent('voden_hoist:finishLitterRecovery',id,false);return end
    for i=1,GetVehicleMaxNumberOfPassengers(vehicle)-1 do if IsVehicleSeatFree(vehicle,i,true) then seat=i;break end end
    if seat==nil and GetVehicleMaxNumberOfPassengers(vehicle)>0 and IsVehicleSeatFree(vehicle,0,true) then seat=0 end
    if seat==nil then TriggerServerEvent('voden_hoist:finishLitterRecovery',id,false);return end
    stopPatient();ClearPedTasksImmediately(ped);SetPedIntoVehicle(ped,vehicle,seat)
    CreateThread(function()
        Wait(100)
        if GetVehiclePedIsIn(ped,false)~=vehicle then TriggerServerEvent('voden_hoist:finishLitterRecovery',id,false);return end
        local deadline=GetGameTimer()+6500
        while GetGameTimer()<deadline do
            local current=states[id]
            if not current or current.litterPatient~=me then return end
            if GetVehiclePedIsIn(ped,false)~=vehicle then return end
            TriggerServerEvent('voden_hoist:finishLitterRecovery',id,true);Wait(250)
        end
    end)
end)
CreateThread(function()
    while true do
        Wait(500)
        if patientPed and GetGameTimer()-patientSeen>650 then stopPatient() end
        if not registered and GetResourceState('ox_target')=='started' then registerOptions() end
    end
end)

AddEventHandler('onClientResourceStop',function(name)
    if name == 'ox_target' then zones={}; registered=false end
    if name ~= GetCurrentResourceName() then return end
    if registered and GetResourceState('ox_target')=='started' then exports.ox_target:removeGlobalOption(optionNames) end
    stopPatient()
    for id in pairs(states) do VodenRemoveLitter(id,true) end
    SetModelAsNoLongerNeeded(model)
end)
