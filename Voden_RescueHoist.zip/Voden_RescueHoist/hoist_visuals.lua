local hooks = {}
local groundSamples = {}
local model = `voden_rescue_hook`
local renderFrame, triangles = -1, 0
local function finite(n) return type(n) == "number" and n == n and math.abs(n) < 100000 end
local function valid(v) return v and finite(v.x) and finite(v.y) and finite(v.z) end

local dictionary = 'voden_steel_cable'

local function cross(a, b)
    return vector3(a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x)
end

function VodenDrawSteelCable(top, bottom, paidLength, grounded, id)
    if not valid(top) or not valid(bottom) or not finite(paidLength) then return end
    local frame = GetFrameCount()
    if renderFrame ~= frame then renderFrame = frame; triangles = 0 end
    if triangles >= 512 then return end
    local delta = bottom - top
    local length = #delta
    if length < 0.001 or length > 100 then return end
    if #(GetGameplayCamCoord() - (top + bottom) * 0.5) > 100 then return end
    RequestStreamedTextureDict(dictionary, false)
    local textured = HasStreamedTextureDictLoaded(dictionary)
    local direction = delta / length
    local reference = math.abs(direction.z) > 0.95 and vector3(1,0,0) or vector3(0,0,1)
    local u = cross(direction, reference); u = u / #u
    local v = cross(direction, u)
    local radius = (Config.SteelCableDiameter or 0.009) * 0.5
    local sides = 4
    local points = {top, bottom}
    -- Only grounded loads can collect loose cable. Keep the long span straight.
    if grounded and paidLength > length+0.02 then
        local cached = groundSamples[id]
        local now = GetGameTimer()
        if not cached or now-cached.time > 500 or #(cached.position-bottom)>0.5 then
            local found, z = GetGroundZFor_3dCoord(bottom.x,bottom.y,bottom.z+0.5,false)
            cached = {time=now,position=bottom,z=found and z or nil}
            groundSamples[id] = cached
        end
        if cached.z then
            local floor = math.min(bottom.z,cached.z+radius+0.015)
            local contact = vector3(bottom.x,bottom.y,floor)
            local route = #(top-contact)+#(bottom-contact)
            if paidLength < route then
                -- Let the short return to the hook sag down until it reaches ground.
                local low, high = floor, bottom.z
                for iteration=1,12 do
                    local z=(low+high)*0.5
                    local test=vector3(bottom.x,bottom.y,z)
                    if #(top-test)+#(bottom-test)>paidLength then low=z else high=z end
                end
                points={top,vector3(bottom.x,bottom.y,(low+high)*0.5),bottom}
            else
                -- Stable, irregular overlapping loops. Payout enlarges the pile;
                -- retraction gathers it without moving the anchored load.
                local shape, perimeter = {vector3(0,0,0)}, 0
                for k=1,24 do
                    local t=k/24
                    local angle=t*math.pi*6
                    local envelope=math.sin(math.pi*t)
                    local q=vector3(envelope*math.cos(angle),envelope*math.sin(angle)*0.7,0)
                    if k==24 then q=vector3(0,0,0) end
                    perimeter=perimeter+#(q-shape[#shape])
                    shape[#shape+1]=q
                end
                local scale=math.max(0,paidLength-route)/perimeter
                points={top,contact}
                for k=2,#shape do points[#points+1]=contact+shape[k]*scale end
                points[#points+1]=bottom
            end
        end
    else
        groundSamples[id]=nil
    end

    local function tri(a,b,c,ua,va,ub,vb,uc,vc,shade)
        if triangles >= 512 or not valid(a) or not valid(b) or not valid(c) then return end
        triangles = triangles+1
        if textured then
            DrawTexturedPoly(a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z,
                shade,shade,shade,255,dictionary,'voden_steel_cable',ua,va,1.0,ub,vb,1.0,uc,vc,1.0)
        else
            DrawPoly(a.x,a.y,a.z,b.x,b.y,b.z,c.x,c.y,c.z,shade,shade,shade,255)
        end
    end
    for i=1,#points-1 do
        local p = points[i]
        local q = points[i+1]
        local tangent = q-p
        if #tangent > 0.00001 then
            tangent=tangent/#tangent
            local ref=math.abs(tangent.z)>0.95 and vector3(1,0,0) or vector3(0,0,1)
            u=cross(tangent,ref); u=u/#u; v=cross(tangent,u)
        end
        for j=0,sides-1 do
            local a = j*math.pi*2/sides
            local b = (j+1)*math.pi*2/sides
            local r1 = (u*math.cos(a)+v*math.sin(a))*radius
            local r2 = (u*math.cos(b)+v*math.sin(b))*radius
            local x,y,z,w = p+r1,q+r1,q+r2,p+r2
            local shade = math.floor(165+75*math.cos(a-0.7))
            -- Both windings keep the slender cable visible from every camera angle.
            tri(x,z,y,j/sides,0,(j+1)/sides,1,j/sides,1,shade)
            tri(x,w,z,j/sides,0,(j+1)/sides,0,(j+1)/sides,1,shade)
            tri(x,y,z,j/sides,0,j/sides,1,(j+1)/sides,1,shade)
            tri(x,z,w,j/sides,0,(j+1)/sides,1,(j+1)/sides,0,shade)
        end
    end
end

function VodenRemoveHoistVisual(id)
    groundSamples[id] = nil
    local entry = hooks[id]
    if entry and DoesEntityExist(entry.object) then DeleteEntity(entry.object) end
    hooks[id] = nil
end

function VodenDrawRescueHook(id, position, heading)
    if not valid(position) or not finite(heading) then return end
    if #(GetGameplayCamCoord()-position) > 100 then VodenRemoveHoistVisual(id); return end
    local entry = hooks[id]
    if not entry or not DoesEntityExist(entry.object) then
        RequestModel(model)
        if not HasModelLoaded(model) then return end
        local obj = CreateObjectNoOffset(model,position.x,position.y,position.z,false,false,false)
        if obj == 0 then return end
        SetEntityCollision(obj,false,false)
        FreezeEntityPosition(obj,true)
        SetEntityInvincible(obj,true)
        entry = {object=obj}; hooks[id] = entry
    end
    entry.updated = GetGameTimer()
    SetEntityCoordsNoOffset(entry.object,position.x,position.y,position.z,false,false,false)
    SetEntityRotation(entry.object,0,0,heading,2,true)
end

CreateThread(function()
    while true do
        Wait(1000)
        for id, entry in pairs(hooks) do
            if GetGameTimer()-(entry.updated or 0)>1500 then VodenRemoveHoistVisual(id) end
        end
    end
end)

AddEventHandler('onClientResourceStop',function(name)
    if name ~= GetCurrentResourceName() then return end
    for id in pairs(hooks) do VodenRemoveHoistVisual(id) end
    SetStreamedTextureDictAsNoLongerNeeded(dictionary)
    SetModelAsNoLongerNeeded(model)
end)
